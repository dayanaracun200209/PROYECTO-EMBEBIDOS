#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hardware_daemon.py
 - LCD I2C 16×2
 - Botón GPIO en BCM17
 - Webcam USB (Logitech) con OpenCV
 - POST a /api/recognize
 - Al éxito, pone HIGH en BCM27 durante 5 s
"""

import os
import shutil
import requests
import cv2
from time import sleep
from datetime import datetime
import RPi.GPIO as GPIO
from RPLCD.i2c import CharLCD

# GPIO pins
BUTTON_PIN = 17  # BCM17
SOL_PIN    = 27  # BCM27

# GPIO setup
GPIO.setmode(GPIO.BCM)
GPIO.setup(BUTTON_PIN, GPIO.IN,  pull_up_down=GPIO.PUD_UP)
GPIO.setup(SOL_PIN,    GPIO.OUT, initial=GPIO.LOW)

# LCD setup (PCF8574 @0x27)
lcd = CharLCD('PCF8574', 0x27, cols=16, rows=2)

# Uploads folder (Flask espera aquí)
UPLOADS_FOLDER = "/home/pi/Proyecto_Embebidos_ReconocimientoFacial_P106/static/uploads"
os.makedirs(UPLOADS_FOLDER, exist_ok=True)

def display_sequence():
    lcd.clear()
    lcd.write_string('Presione el boton')
    while GPIO.input(BUTTON_PIN):
        sleep(0.1)

    # Cuenta atrás
    lcd.clear(); lcd.write_string('Tomando foto...'); sleep(1)
    for i in (3,2,1):
        lcd.clear(); lcd.write_string(str(i)); sleep(1)
    lcd.clear(); lcd.write_string('Sonria'); sleep(2)

    # Captura
    now_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    tmp_path = f"/tmp/capture_{now_str}.jpg"
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH,  640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    ret, frame = cap.read()
    cap.release()
    if not ret:
        lcd.clear(); lcd.write_string('Error Camara'); sleep(2)
        return
    cv2.imwrite(tmp_path, frame)

    # Copia a uploads
    upload_filename = f"access_{now_str}.jpg"
    upload_path     = os.path.join(UPLOADS_FOLDER, upload_filename)
    shutil.copy(tmp_path, upload_path)

    # Llamada a Flask
    lcd.clear(); lcd.write_string('Reconociendo...')
    with open(upload_path, 'rb') as f:
        r = requests.post('http://localhost:5000/api/recognize',
                          files={'image': (upload_filename, f)})
    try:
        result = r.json()
    except ValueError:
        result = {'success': False}

    # Resultado + solenoide
    lcd.clear()
    if result.get('success'):
        GPIO.output(SOL_PIN, GPIO.HIGH)
        lcd.write_string('Acceso Permitido')
        sleep(1.5)
        sleep(5)               # ← 5 segundos de apertura
        GPIO.output(SOL_PIN, GPIO.LOW)
        lcd.clear(); lcd.write_string('Bienvenido')
        lcd.crlf(); lcd.write_string(str(result['user'])[:16])
        sleep(2)
    else:
        lcd.write_string('Acceso Denegado'); sleep(2)
        lcd.clear(); lcd.write_string('Contacte admin'); sleep(2)

def main():
    try:
        while True:
            display_sequence()
    except KeyboardInterrupt:
        pass
    finally:
        lcd.clear()
        GPIO.cleanup()

if __name__ == '__main__':
    main()
