import os
import pickle
import json
from datetime import datetime
from flask import Flask, render_template, request, jsonify, url_for, redirect
from werkzeug.utils import secure_filename
import face_recognition
import shutil
import RPi.GPIO as GPIO
from time import sleep

app = Flask(__name__)

# ————— GPIO para solenoide —————
SOL_PIN = 27
GPIO.setmode(GPIO.BCM)
GPIO.setup(SOL_PIN, GPIO.OUT, initial=GPIO.LOW)

# ————— Configuración Flask y rutas de ficheros —————
app.config['UPLOAD_FOLDER']    = os.path.join('static', 'uploads')
app.config['KNOWN_FACES_DIR']  = os.path.join('known_faces', 'users')
app.config['ENCODINGS_FILE']   = os.path.join('known_faces', 'encodings.pkl')
LOG_FILE                      = os.path.join('known_faces', 'logs.json')
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['KNOWN_FACES_DIR'], exist_ok=True)
os.makedirs('known_faces', exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def load_known_encodings():
    enc_file = app.config['ENCODINGS_FILE']
    if os.path.exists(enc_file):
        with open(enc_file, 'rb') as f:
            return pickle.load(f)
    return {}

def save_known_encodings(encodings_dict):
    enc_file = app.config['ENCODINGS_FILE']
    os.makedirs(os.path.dirname(enc_file), exist_ok=True)
    with open(enc_file, 'wb') as f:
        pickle.dump(encodings_dict, f)

def get_registered_users():
    base_dir = app.config['KNOWN_FACES_DIR']
    return sorted(d for d in os.listdir(base_dir)
                  if os.path.isdir(os.path.join(base_dir, d)))

def register_new_user(username, files):
    saved_any = False
    for file in files:
        if not (file and allowed_file(file.filename)):
            continue
        fn = secure_filename(f"{username}_{datetime.now().strftime('%Y%m%d%H%M%S')}_{file.filename}")
        temp_path = os.path.join(app.config['UPLOAD_FOLDER'], fn)
        file.save(temp_path)

        img = face_recognition.load_image_file(temp_path)
        locs = face_recognition.face_locations(img)
        if len(locs) != 1:
            os.remove(temp_path)
            return False, "Cada imagen debe tener exactamente 1 rostro."
        enc = face_recognition.face_encodings(img, known_face_locations=locs)[0]

        user_folder = os.path.join(app.config['KNOWN_FACES_DIR'], username)
        os.makedirs(user_folder, exist_ok=True)
        dest = os.path.join(user_folder, fn)
        os.replace(temp_path, dest)

        known = load_known_encodings()
        known.setdefault(username, []).append(enc)
        save_known_encodings(known)
        saved_any = True

    if saved_any:
        return True, f"Usuario «{username}» registrado con éxito."
    else:
        return False, "No se registró ninguna foto válida."

def save_log_entry(entry):
    logs = []
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, 'r') as f:
            try:
                logs = json.load(f)
            except:
                logs = []
    logs.append(entry)
    with open(LOG_FILE, 'w') as f:
        json.dump(logs, f, indent=2)

@app.route('/', methods=['GET', 'POST'])
def admin():
    message = None
    if request.method == 'POST':
        username = request.form.get('name', '').strip()
        files = request.files.getlist('image')
        if not username or ' ' in username:
            message = "Nombre no válido (sin espacios)."
        elif not files or len([f for f in files if f.filename]) == 0:
            message = "Selecciona al menos una imagen JPG/PNG válida."
        elif len(files) > 3:
            message = "Puedes subir hasta 3 imágenes."
        else:
            valid_files = [f for f in files if f.filename]
            ok, msg = register_new_user(username, valid_files)
            message = msg
    users = get_registered_users()
    return render_template('admin.html', users=users, message=message)

@app.route('/delete_user/<username>', methods=['POST'])
def delete_user(username):
    user_folder = os.path.join(app.config['KNOWN_FACES_DIR'], username)
    if os.path.exists(user_folder):
        shutil.rmtree(user_folder)
    known = load_known_encodings()
    if username in known:
        del known[username]
        save_known_encodings(known)
    return redirect(url_for('admin'))

@app.route('/api/recognize', methods=['POST'])
def recognize():
    file = request.files.get('image')
    if not file or file.filename == '':
        return jsonify({'success': False, 'error': 'No file'})

    fn = secure_filename(f"access_{datetime.now().strftime('%Y%m%d%H%M%S')}_{file.filename}")
    temp_path = os.path.join(app.config['UPLOAD_FOLDER'], fn)
    file.save(temp_path)

    img = face_recognition.load_image_file(temp_path)
    locs = face_recognition.face_locations(img)
    if len(locs) != 1:
        save_log_entry({
            'filename': fn,
            'user': "Unknown",
            'datetime': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'status': 'Denegado'
        })
        return jsonify({'success': False, 'error': 'No unique face'})

    enc = face_recognition.face_encodings(img, known_face_locations=locs)[0]
    known = load_known_encodings()
    found = None
    for user, encs in known.items():
        if any(face_recognition.compare_faces(encs, enc, tolerance=0.5)):
            found = user
            break

    status = 'Aceptado' if found else 'Denegado'
    save_log_entry({
        'filename': fn,
        'user': found or 'Unknown',
        'datetime': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'status': status
    })

    if found:
        # Dispara la solenoide 5 segundos
        GPIO.output(SOL_PIN, GPIO.HIGH)
        sleep(5)
        GPIO.output(SOL_PIN, GPIO.LOW)
        return jsonify({'success': True, 'user': found})
    else:
        return jsonify({'success': False})

@app.route('/access_log')
def access_log():
    logs = []
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, 'r') as f:
            try:
                logs = json.load(f)
            except:
                logs = []
    logs = logs[::-1]
    return render_template('log.html', logs=logs)

@app.route('/remote', methods=['GET', 'POST'])
def remote():
    message = None
    if request.method == 'POST':
        # Pulso remoto para abrir solenoide
        GPIO.output(SOL_PIN, GPIO.HIGH)
        sleep(5)
        GPIO.output(SOL_PIN, GPIO.LOW)
        message = "Cerradura abierta"
    return render_template('remote.html', message=message)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
