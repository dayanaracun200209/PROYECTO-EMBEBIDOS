# Sistema de Reconocimiento Facial Embebido con Raspberry Pi

Proyecto universitario de sistemas embebidos: **Reconocimiento Facial, registro web y control físico de acceso** mediante Raspberry Pi Zero 2W, botón físico y pantalla LCD.

---

## 🧩 **Características**

- **Registro web** de usuarios con hasta 3 fotos por usuario (mejor precisión).
- **Reconocimiento facial en tiempo real** con cámara Raspberry Pi.
- **Acceso físico**: Botón en GPIO 17 y mensajes en pantalla LCD I2C (16x2).
- **Log de todos los intentos de acceso** (aceptado/denegado) con foto, fecha/hora y usuario.
- **Eliminación de usuarios** desde la web.
- **Interfaz web simple y funcional** (Flask + Jinja2).
- **Fácil despliegue y administración**.

---

## 📂 **Estructura del Proyecto**

Proyecto_Embebidos_ReconocimientoFacial_P106/
│
├── app.py # Servidor Flask (web y API)
├── hardware_daemon.py # Daemon para botón, cámara y LCD
├── requirements.txt # Dependencias Python
├── README.md
│
├── known_faces/
│ ├── users/ # Carpetas por usuario (fotos)
│ ├── encodings.pkl # Encodings de rostros (pickle)
│ └── logs.json # Registro de accesos (creado al primer acceso)
│
├── static/
│ ├── uploads/ # Fotos de accesos
│ └── styles.css # Estilos CSS (opcional)
│
└── templates/
├── admin.html # Página principal (admin usuarios)
└── log.html # Log de accesos


---

## ⚡ **Requisitos de Hardware**

- **Raspberry Pi Zero 2W** (o compatible)
- **Cámara Raspberry Pi** (CSI o USB)
- **Botón físico** (conectado a GPIO 17 / pin 11)
- **Pantalla LCD I2C 16x2** (dirección I2C usualmente 0x27)

---

## 🛠️ **Instalación y Uso**

### 1. **Clona el repositorio en tu Raspberry Pi**

```bash
git clone https://github.com/Franklinp18/Proyecto_Embebidos_ReconocimientoFacial_P106.git
cd Proyecto_Embebidos_ReconocimientoFacial_P106

### 2. Configura tu entorno Python

Se recomienda usar entorno virtual:

python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

Si tienes error con picamera:

sudo apt update
sudo apt install python3-picamera



### 3. Conecta hardware

    Botón físico al GPIO17 (pin 11 físico, con resistencia de pull-down).

    LCD I2C a los pines I2C (SDA/SCL).

    Cámara conectada y habilitada.

### 4. Corre el sistema

Abre dos terminales o usa tmux:

    Terminal 1:

	python3 app.py

    Terminal 2:

	python3 hardware_daemon.py

####🌐 Uso de la Interfaz Web

    Accede desde tu navegador:
    http://<ip_de_tu_raspberry>:5000/

    Registra usuarios (hasta 3 fotos por usuario).

    Borra usuarios con la X.

    Consulta el log de accesos: /access_log
    (cada intento se registra, sea aceptado o denegado, con estado coloreado y foto).

####🔍 Notas técnicas

    No usa base de datos SQL, solo archivos pickle y JSON.

    El log (logs.json) se crea tras el primer intento de acceso.

    Las fotos de accesos se guardan en static/uploads/.

    Puedes limpiar los logs o las fotos manualmente si el espacio es un problema.

####🛡️ Mejoras sugeridas

    Agregar autenticación para el panel admin.

    Permitir limpiar logs desde la web.

    Usar base de datos SQL si hay muchos usuarios.

    Compatibilidad con más modelos de cámara.

##👨‍💻 Autores

Lizbeth Cun – Franklin Pelaez
Sistemas Embebidos – Paralelo 106 – PAO I 2025
